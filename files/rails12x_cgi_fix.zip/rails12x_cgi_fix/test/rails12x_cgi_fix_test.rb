require 'rubygems'
require 'action_controller'
require 'test/unit'
require File.expand_path(File.dirname(__FILE__) + "/../../../../config/environment")
require 'test_help'

class Rails12xCgiFixTest < Test::Unit::TestCase
  # Replace this with your real tests.
  def test_this_plugin
    assert_nothing_raised do
      CGI.new
    end
  end
end
