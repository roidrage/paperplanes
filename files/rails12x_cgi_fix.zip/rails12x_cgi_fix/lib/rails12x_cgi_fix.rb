if RAILS_GEM_VERSION.eql? "1.2.3" or RAILS_GEM_VERSION.eql? "1.2.2"
  class CGI
    module QueryExtension
      alias :rails_read_query :read_query
      private
      # Fixes a bug in Rails 1.2.3 which would cause CGI module to deal with nil objects
      def read_query
        qs = rails_read_query || ''
      end
    end
  end
end