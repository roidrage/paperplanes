class BackgroundController < ApplicationController
  def index
    render
  end
  
  def start_worker
    session[:job_key] = ::MiddleMan.new_worker(:class => :sample_worker, :args => {:times => params[:times]})
    redirect_to :action => "index"
  end
  
  def progress
    progress = "Not running"
    begin
      worker = ::MiddleMan.worker(session[:job_key])
      progress = "Current progress: #{worker.progress}"
    rescue Exception => e
      # Worker/BackgrounDRb not running
      logger.error("#{e}")
    end
    
    render :update do |page|
      page.replace_html :progress, progress
    end
  end
end
