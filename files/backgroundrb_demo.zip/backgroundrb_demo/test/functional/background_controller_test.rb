require File.dirname(__FILE__) + '/../test_helper'
require 'background_controller'

# Re-raise errors caught by the controller.
class BackgroundController; def rescue_action(e) raise e end; end

class BackgroundControllerTest < Test::Unit::TestCase
  def setup
    @controller = BackgroundController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
  end

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
