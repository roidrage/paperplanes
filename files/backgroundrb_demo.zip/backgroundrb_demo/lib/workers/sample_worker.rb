class SampleWorker < BackgrounDRb::Worker::RailsBase
  def do_work(args)
    args[:times] ||= 10
    args[:times].times do |number|
      sleep 5
      results[:progress] = number
    end
  end
  
  def progress
    return results[:progress]
  end
end

SampleWorker.register